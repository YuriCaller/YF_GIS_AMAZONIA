# -*- coding: utf-8 -*-
"""
Geometry Calculator — calcula atributos geométricos sobre la misma capa.
Soporta polígonos, líneas y puntos. No crea capas nuevas.
Las funciones reciben `opciones` como dict {key: nombre_campo_destino}.
Autor: Yuri F. Caller Córdova — TUCSA / gis-amazonia.pe
"""

from math import atan2, degrees
from qgis.core import (
    QgsProject, QgsField, QgsDistanceArea,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsWkbTypes
)
from qgis.PyQt.QtCore import QVariant


def _get_distance_area(layer, target_crs_authid=None):
    da = QgsDistanceArea()
    crs = QgsCoordinateReferenceSystem(target_crs_authid) if target_crs_authid else layer.crs()
    da.setSourceCrs(crs, QgsProject.instance().transformContext())
    da.setEllipsoid(crs.ellipsoidAcronym() or "WGS84")
    return da


def _ensure_field(layer, field_name, field_type):
    """Crea el campo si no existe."""
    if layer.fields().indexOf(field_name) == -1:
        layer.dataProvider().addAttributes([QgsField(field_name, field_type)])
        layer.updateFields()


def _transform_geom(feature, layer, target_crs_authid):
    geom = feature.geometry()
    if target_crs_authid and layer.crs().authid() != target_crs_authid:
        target_crs = QgsCoordinateReferenceSystem(target_crs_authid)
        transform = QgsCoordinateTransform(
            layer.crs(), target_crs,
            QgsProject.instance().transformContext()
        )
        geom.transform(transform)
    return geom


def calcular_azimut(p1, p2):
    dx = p2.x() - p1.x()
    dy = p2.y() - p1.y()
    return degrees(atan2(dx, dy)) % 360


def azimut_a_gms(az):
    """Convierte azimut decimal a string GMS: 324°15'22.00" """
    g = int(az)
    md = (az - g) * 60
    m = int(md)
    s = (md - m) * 60
    return "{:03d}°{:02d}'{:05.2f}\"" .format(g, m, s)


# ─────────────────────────────────────────────────────────────────────────────
# POLÍGONOS
# opciones: {"area_ha": "mi_campo", "perimetro_m": "perim", ...}
# ─────────────────────────────────────────────────────────────────────────────

def calcular_poligono(layer, opciones, target_crs_authid=None, solo_seleccion=False):
    da = _get_distance_area(layer, target_crs_authid)
    layer.startEditing()

    # Preparar campos necesarios con sus tipos
    tipo_por_key = {
        "area_ha": QVariant.Double, "area_m2": QVariant.Double,
        "perimetro_m": QVariant.Double,
        "centroide_x": QVariant.Double, "centroide_y": QVariant.Double,
    }
    for key, fname in opciones.items():
        _ensure_field(layer, fname, tipo_por_key[key])

    features = layer.selectedFeatures() if solo_seleccion else layer.getFeatures()
    count = 0

    for feat in features:
        geom = _transform_geom(feat, layer, target_crs_authid)
        updates = {}

        if "area_ha" in opciones:
            updates[opciones["area_ha"]] = round(da.measureArea(geom) / 10000, 4)
        if "area_m2" in opciones:
            updates[opciones["area_m2"]] = round(da.measureArea(geom), 4)
        if "perimetro_m" in opciones:
            updates[opciones["perimetro_m"]] = round(da.measurePerimeter(geom), 4)
        if "centroide_x" in opciones or "centroide_y" in opciones:
            c = geom.centroid().asPoint()
            if "centroide_x" in opciones:
                updates[opciones["centroide_x"]] = round(c.x(), 4)
            if "centroide_y" in opciones:
                updates[opciones["centroide_y"]] = round(c.y(), 4)

        for fname, value in updates.items():
            idx = layer.fields().indexOf(fname)
            if idx >= 0:
                layer.changeAttributeValue(feat.id(), idx, value)
        count += 1

    layer.commitChanges()
    return count


# ─────────────────────────────────────────────────────────────────────────────
# LÍNEAS
# ─────────────────────────────────────────────────────────────────────────────

def calcular_linea(layer, opciones, target_crs_authid=None, solo_seleccion=False):
    da = _get_distance_area(layer, target_crs_authid)
    layer.startEditing()

    tipo_por_key = {
        "longitud_m": QVariant.Double, "azimut_dec": QVariant.Double,
        "azimut_gms": QVariant.String,
        "inicio_x": QVariant.Double, "inicio_y": QVariant.Double,
        "fin_x": QVariant.Double, "fin_y": QVariant.Double,
    }
    for key, fname in opciones.items():
        _ensure_field(layer, fname, tipo_por_key[key])

    features = layer.selectedFeatures() if solo_seleccion else layer.getFeatures()
    count = 0

    for feat in features:
        geom = _transform_geom(feat, layer, target_crs_authid)
        updates = {}

        if "longitud_m" in opciones:
            updates[opciones["longitud_m"]] = round(da.measureLength(geom), 4)

        vertices = list(geom.vertices())
        if vertices:
            p0, pn = vertices[0], vertices[-1]
            if "azimut_dec" in opciones or "azimut_gms" in opciones:
                az = calcular_azimut(p0, pn)
                if "azimut_dec" in opciones:
                    updates[opciones["azimut_dec"]] = round(az, 6)
                if "azimut_gms" in opciones:
                    updates[opciones["azimut_gms"]] = azimut_a_gms(az)
            if "inicio_x" in opciones:
                updates[opciones["inicio_x"]] = round(p0.x(), 4)
            if "inicio_y" in opciones:
                updates[opciones["inicio_y"]] = round(p0.y(), 4)
            if "fin_x" in opciones:
                updates[opciones["fin_x"]] = round(pn.x(), 4)
            if "fin_y" in opciones:
                updates[opciones["fin_y"]] = round(pn.y(), 4)

        for fname, value in updates.items():
            idx = layer.fields().indexOf(fname)
            if idx >= 0:
                layer.changeAttributeValue(feat.id(), idx, value)
        count += 1

    layer.commitChanges()
    return count


# ─────────────────────────────────────────────────────────────────────────────
# PUNTOS
# ─────────────────────────────────────────────────────────────────────────────

def calcular_punto(layer, opciones, target_crs_authid=None, solo_seleccion=False):
    layer.startEditing()

    tipo_por_key = {
        "coord_x": QVariant.Double,
        "coord_y": QVariant.Double,
        "elevacion_z": QVariant.Double,
    }
    for key, fname in opciones.items():
        _ensure_field(layer, fname, tipo_por_key[key])

    features = layer.selectedFeatures() if solo_seleccion else layer.getFeatures()
    count = 0

    for feat in features:
        geom = _transform_geom(feat, layer, target_crs_authid)
        punto = geom.asPoint()
        updates = {}

        if "coord_x" in opciones:
            updates[opciones["coord_x"]] = round(punto.x(), 6)
        if "coord_y" in opciones:
            updates[opciones["coord_y"]] = round(punto.y(), 6)
        if "elevacion_z" in opciones and QgsWkbTypes.hasZ(geom.wkbType()):
            pt3d = list(geom.vertices())[0]
            updates[opciones["elevacion_z"]] = round(pt3d.z(), 4)

        for fname, value in updates.items():
            idx = layer.fields().indexOf(fname)
            if idx >= 0:
                layer.changeAttributeValue(feat.id(), idx, value)
        count += 1

    layer.commitChanges()
    return count
