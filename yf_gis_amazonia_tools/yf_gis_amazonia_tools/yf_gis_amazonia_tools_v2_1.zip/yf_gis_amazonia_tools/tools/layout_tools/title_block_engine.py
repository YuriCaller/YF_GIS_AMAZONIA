# -*- coding: utf-8 -*-
"""
Title Block Engine — 4 plantillas de cajetín profesionales.
Validadas directamente en QGIS 3.44 via MCP.

  1. sencillo            — clásico horizontal
  2. bim_tecnico         — azul marino + verde (D1)
  3. catastral_forestal  — verde selva + dorado (D2) ← validado en QGIS
  4. premium             — antracita + rojo (D3)

Autor: Yuri F. Caller Córdova — TUCSA / gis-amazonia.pe
"""

import os
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtCore import Qt
from qgis.core import (
    QgsLayoutItemLabel, QgsLayoutItemShape, QgsLayoutItemPicture,
    QgsLayoutItemMap, QgsLayoutItemLegend, QgsLayoutItemGroup,
    QgsLayoutSize, QgsLayoutPoint, QgsUnitTypes,
    QgsFillSymbol, QgsSimpleFillSymbolLayer, QgsProject,
)

MM = QgsUnitTypes.LayoutMillimeters

# ─────────────────────────────────────────────────────────────────────────────
# Plantillas
# ─────────────────────────────────────────────────────────────────────────────

PLANTILLAS_CAJETIN = {
    "sencillo": {
        "nombre":      "Sencillo",
        "descripcion": "Clásico horizontal, entregables rápidos",
        "ancho": 100.0, "alto": 45.0,
    },
    "bim_tecnico": {
        "nombre":      "BIM / Técnico",
        "descripcion": "Catastro urbano, GOREMAD, levantamientos",
        "ancho": 68.0, "alto": 270.0,
        "CF": "#1a3a5c", "CH": "#12263f", "CP": "#2c9c6e", "CA": "#2c9c6e",
        "CS": "#2c5f8a", "CL": "#2c9c6e", "CV": "#d0e8f0",
        "CB": "#ffffff",  "CM": "#7ab3d4",
    },
    "catastral_forestal": {
        "nombre":      "Catastral / Forestal",
        "descripcion": "POA, DEMA, SERFOR, ACCA, comunidades",
        "ancho": 68.0, "alto": 270.0,
        "CF": "#0d2b1a", "CH": "#071a10", "CP": "#e8a820", "CA": "#e8a820",
        "CS": "#1a4d2e", "CL": "#e8a820", "CV": "#a0d4b0",
        "CB": "#ffffff",  "CM": "#5a9e6f",
    },
    "premium": {
        "nombre":      "Premium",
        "descripcion": "Presentaciones, clientes, propuestas TUCSA",
        "ancho": 68.0, "alto": 270.0,
        "CF": "#1c1c1e", "CH": "#111113", "CP": "#e53935", "CA": "#e53935",
        "CS": "#333333", "CL": "#e53935", "CV": "#aaaaaa",
        "CB": "#ffffff",  "CM": "#666666",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _rect(layout, x, y, w, h, fill, stroke=None, sw=0.2):
    item = QgsLayoutItemShape(layout)
    layout.addLayoutItem(item)
    try:    item.setShapeType(QgsLayoutItemShape.Shape.Rectangle)
    except: item.setShapeType(QgsLayoutItemShape.Rectangle)
    item.attemptMove(QgsLayoutPoint(x, y, MM))
    item.attemptResize(QgsLayoutSize(w, h, MM))
    sym = QgsFillSymbol()
    sl  = QgsSimpleFillSymbolLayer()
    sl.setFillColor(QColor(fill))
    sl.setStrokeColor(QColor(stroke or fill))
    sl.setStrokeWidth(sw if stroke else 0)
    sym.changeSymbolLayer(0, sl)
    item.setSymbol(sym)
    item.setFrameEnabled(False)
    item.setBackgroundEnabled(False)
    return item


def _lbl(layout, text, x, y, w, h, size=7, bold=False, italic=False,
         color="#ffffff", halign=Qt.AlignLeft, html=False):
    item = QgsLayoutItemLabel(layout)
    layout.addLayoutItem(item)
    item.attemptMove(QgsLayoutPoint(x, y, MM))
    item.attemptResize(QgsLayoutSize(w, h, MM))
    font = QFont("Arial", int(size))
    font.setBold(bold)
    font.setItalic(italic)
    item.setFont(font)
    item.setFontColor(QColor(color))
    try:
        item.setHAlign(halign)
        item.setVAlign(Qt.AlignVCenter)
    except Exception:
        pass
    item.setMarginX(1.0)
    item.setMarginY(0.3)
    item.setMode(QgsLayoutItemLabel.ModeHtml if html else QgsLayoutItemLabel.ModeFont)
    item.setText(text)
    item.setBackgroundEnabled(False)
    item.setFrameEnabled(False)
    return item


def _norte(layout, x, y, w, h):
    item = QgsLayoutItemPicture(layout)
    layout.addLayoutItem(item)
    for path in [":/images/north_arrows/NorthArrow_02.svg",
                 ":/images/north_arrows/NorthArrow_01.svg"]:
        item.setPicturePath(path)
        if item.picturePath():
            break
    item.attemptMove(QgsLayoutPoint(x, y, MM))
    item.attemptResize(QgsLayoutSize(w, h, MM))
    item.setFrameEnabled(False)
    item.setBackgroundEnabled(False)
    item.setResizeMode(QgsLayoutItemPicture.ZoomResizeFrame)
    return item


def _map_item(layout, x, y, w, h, scale=500000):
    item = QgsLayoutItemMap(layout)
    layout.addLayoutItem(item)
    item.attemptMove(QgsLayoutPoint(x, y, MM))
    item.attemptResize(QgsLayoutSize(w, h, MM))
    item.setScale(scale)
    item.setFrameEnabled(True)
    item.setBackgroundEnabled(True)
    item.setBackgroundColor(QColor("#f0f4f0"))
    item.refresh()
    return item


def _legend_item(layout, x, y, w, h):
    item = QgsLayoutItemLegend(layout)
    layout.addLayoutItem(item)
    item.attemptMove(QgsLayoutPoint(x, y, MM))
    item.attemptResize(QgsLayoutSize(w, h, MM))
    item.setFrameEnabled(False)
    item.setBackgroundEnabled(False)
    item.updateLegend()
    return item


def _var(nombre, fallback=""):
    try:
        val = QgsProject.instance().variable(nombre)
        return val if val else fallback
    except Exception:
        return fallback


# ─────────────────────────────────────────────────────────────────────────────
# Cajetín sencillo (horizontal)
# ─────────────────────────────────────────────────────────────────────────────

def _gen_sencillo(layout, x0, y0, datos, logo_path):
    W, H = 100.0, 45.0
    _rect(layout, x0, y0, W, H, "#ffffff", "#333333", 0.4)
    _rect(layout, x0, y0, W, 8.0, "#2c5f8a")
    titulo = dados = datos.get("titulo", "[% @layout_name %]")
    _lbl(layout, titulo, x0, y0, W-20, 8.0,
         size=8, bold=True, color="#ffffff",
         halign=Qt.AlignCenter, html=True)
    _rect(layout, x0+W-20, y0, 20, 8.0, "#1a3a5c")
    _lbl(layout, datos.get("hoja","01"),
         x0+W-20, y0, 20, 8.0, size=8, bold=True,
         color="#ffffff", halign=Qt.AlignCenter)

    sub = datos.get("subtitulo","")
    if sub:
        _rect(layout, x0, y0+8, W, 5.5, "#f0f4f8")
        _lbl(layout, sub, x0, y0+8, W, 5.5,
             size=6.5, color="#333333", halign=Qt.AlignCenter)

    y = y0 + 14
    _rect(layout, x0+49, y, 0.3, 14, "#cccccc")
    _lbl(layout, "TITULAR",      x0+1,  y, 47, 3.5, size=5, color="#888888")
    _lbl(layout, "ELABORADO POR",x0+51, y, 47, 3.5, size=5, color="#888888")
    _lbl(layout, datos.get("titular",""),
         x0+1, y+3.5, 47, 5.0, size=7, bold=True, color="#000000")
    _lbl(layout, datos.get("elaborado",
         _var("tucsa_elaborado","Ing. Yuri F. Caller Córdova")),
         x0+51, y+3.5, 47, 5.0, size=6.5, color="#000000")
    y += 9.5

    for i, (etq, val, wc, xo) in enumerate([
        ("DATUM",  datos.get("datum","[% @project_crs_description %]"), 34, 0),
        ("ESCALA", datos.get("escala","[% '1:' || format_number(@map_scale,0) %]"), 29, 35),
        ("FECHA",  datos.get("fecha","[% format_date(now(),'MMMM yyyy') %]"), 33, 66),
    ]):
        _lbl(layout, etq, x0+xo+1, y, wc, 3.5, size=5, color="#888888")
        _lbl(layout, val, x0+xo+1, y+3.5, wc, 5.0,
             size=7, bold=True, color="#000000", html=("[%" in val))
        if i < 2:
            _rect(layout, x0+xo+wc, y, 0.3, 9, "#cccccc")

    layout.refresh()


# ─────────────────────────────────────────────────────────────────────────────
# Cajetín moderno vertical — validado en QGIS via MCP
# Estructura: Header → Plano N° con Norte → Campos → Mapa ubicación
#             → Leyenda → Miniatura situación
# ─────────────────────────────────────────────────────────────────────────────

def _gen_moderno(layout, x0, y0, datos, logo_path, plt):
    W  = plt["ancho"];  H  = plt["alto"]
    CF = plt["CF"];     CH = plt["CH"];  CP = plt["CP"]
    CA = plt["CA"];     CS = plt["CS"];  CL = plt["CL"]
    CV = plt["CV"];     CB = plt["CB"];  CM = plt["CM"]
    x1 = x0 + 1.3;     wc = W - 3.0
    items_cajetin = []  # acumula todos los elementos para agrupar

    def R(x, y, w, h, fill, stroke=None, sw=0.2):
        item = _rect(layout, x, y, w, h, fill, stroke, sw)
        items_cajetin.append(item)
        return item

    def L(text, x, y, w, h, **kw):
        item = _lbl(layout, text, x, y, w, h, **kw)
        items_cajetin.append(item)
        return item

    # ── Fondos base ───────────────────────────────────────────────────
    R(x0,     y0, 1.3,   H, CA)
    R(x0+1.3, y0, W-1.3, H, CF)

    # ── Header — título del mapa ──────────────────────────────────────
    h_hdr = 24.0
    R(x1, y0, W-1.3, h_hdr, CH)
    titulo = datos.get("titulo", "[% @layout_name %]")
    L(titulo, x1+0.5, y0+1, W-3, h_hdr-2,
      size=9, bold=True, color=CB,
      halign=Qt.AlignCenter, html=True)

    # ── Número de plano + Norte ───────────────────────────────────────
    h_pln = 28.0
    y_pln = y0 + h_hdr
    R(x1, y_pln, W-1.3, h_pln, CP)
    norte = _norte(layout, x1+1, y_pln+3, 16, 22)
    items_cajetin.append(norte)
    L("PLANO N°", x1+18, y_pln+2, wc-18, 5,
      size=5, color=CB, halign=Qt.AlignRight)
    L(datos.get("hoja", "01"), x1+18, y_pln+7, wc-18, 18,
      size=20, bold=True, color=CB, halign=Qt.AlignRight)

    # ── Campos ────────────────────────────────────────────────────────
    y = y_pln + h_pln + 1.5

    def sep():
        nonlocal y
        R(x1, y, W-1.3, 0.6, CS)
        y += 1.0

    def campo(etq, val, h_val=5.0, html=False,
              bold_val=False, color_val=None, italic_val=False):
        nonlocal y
        sep()
        L(etq, x1+1, y, wc, 3.0, size=4, color=CL)
        y += 3.0
        L(val, x1+1, y, wc, h_val, size=6, bold=bold_val,
          italic=italic_val, color=color_val or CV, html=html)
        y += h_val + 0.5

    def campo2(l1, v1, l2, v2, html1=False, html2=False):
        nonlocal y
        sep()
        wh = wc / 2
        L(l1, x1+1,    y, wh, 3.0, size=4, color=CL)
        L(l2, x1+1+wh, y, wh, 3.0, size=4, color=CL)
        y += 3.0
        L(v1, x1+1,    y, wh, 5.0, size=6, bold=True, color=CV, html=html1)
        L(v2, x1+1+wh, y, wh, 5.0, size=6, bold=True, color=CV, html=html2)
        y += 5.5

    campo("PROYECTO / DESCRIPCIÓN",
          datos.get("subtitulo", datos.get("titulo", "[% @layout_name %]")),
          h_val=6.5, html=True, bold_val=True, italic_val=True, color_val=CB)
    campo("TITULAR", datos.get("titular", ""),
          bold_val=True, color_val=CB)
    campo2("DATUM",
           datos.get("datum", "[% @project_crs_description %]"),
           "ESCALA",
           datos.get("escala", "[% '1:' || format_number(@map_scale,0) %]"),
           html2=True)
    ubic = datos.get("ubicacion", "")
    if ubic:
        campo("UBICACIÓN", ubic, h_val=6.0)
    area  = datos.get("area", "")
    perim = datos.get("perimetro", "")
    if area or perim:
        campo2("ÁREA", area, "PERÍMETRO", perim)

    sep()
    L("ELABORADO POR", x1+1, y, wc, 3.0, size=4, color=CL)
    y += 3.0
    elaborado = datos.get("elaborado",
        _var("tucsa_elaborado", "Ing. Yuri F. Caller Córdova"))
    L(elaborado, x1+1, y, wc, 4.0, size=6, bold=True, color=CB)
    y += 4.0
    cip = datos.get("cip", _var("tucsa_cip", "CIP N° 214377 — TUCSA"))
    L(cip, x1+1, y, wc, 3.5, size=5, color=CM)
    y += 4.5
    campo2("FECHA",
           datos.get("fecha", "[% format_date(now(),'MM/dd/yyyy') %]"),
           "TAMAÑO",
           "[% @layout_pagewidth %] x [% @layout_pageheight %] mm",
           html1=True, html2=True)

    # ── Mapa de ubicación ─────────────────────────────────────────────
    sep()
    L("UBICACIÓN", x1+1, y, wc, 3.0, size=4, color=CL)
    y += 3.5
    h_ubic = 38.0
    mapa_ubic = _map_item(layout, x1+1, y, wc-1, h_ubic, scale=500000)
    items_cajetin.append(mapa_ubic)
    y += h_ubic + 1.5

    # ── Leyenda ───────────────────────────────────────────────────────
    sep()
    L("LEYENDA", x1+1, y, wc, 3.0, size=4, color=CL)
    y += 3.5
    ley = _legend_item(layout, x1+1, y, wc-1, 25.0)
    items_cajetin.append(ley)
    y += 26.5

    # ── Miniatura situación ───────────────────────────────────────────
    espacio = (y0 + H) - y - 2.0
    if espacio > 8:
        sep()
        L("SITUACIÓN", x1+1, y, wc, 3.0, size=4, color=CL)
        y += 3.5
        mini = _map_item(layout, x1+1, y, wc-1, max(5, espacio-4), scale=10000000)
        items_cajetin.append(mini)

    # ── Agrupar todos los elementos ───────────────────────────────────
    try:
        group = QgsLayoutItemGroup(layout)
        layout.addLayoutItem(group)
        for item in items_cajetin:
            group.addItem(item)
    except Exception:
        pass  # Si falla el agrupado, los items quedan sueltos pero funcionales

    layout.refresh()


# ─────────────────────────────────────────────────────────────────────────────
# Entry point público
# ─────────────────────────────────────────────────────────────────────────────

def generar_cajetin(layout, plantilla_key, pos_x, pos_y,
                    datos, logo_path=None, grupo_nombre="YF_Cajetin"):
    plt = PLANTILLAS_CAJETIN.get(plantilla_key, PLANTILLAS_CAJETIN["sencillo"])
    if plantilla_key == "sencillo":
        _gen_sencillo(layout, pos_x, pos_y, datos, logo_path)
    else:
        _gen_moderno(layout, pos_x, pos_y, datos, logo_path, plt)


def get_variables_proyecto():
    return {
        "elaborado":  _var("tucsa_elaborado",
                           "Ing. Yuri F. Caller C\u00f3rdova \u2014 CIP N\u00b0 214377"),
        "empresa":    _var("tucsa_empresa",
                           "TUCSA \u2014 Training Universal Company SAC"),
        "datum":      _var("tucsa_datum",    "[% @project_crs_description %]"),
        "escala":     "[% '1:' || format_number(@map_scale,0) %]",
        "fecha":      "[% format_date(now(),'MM/dd/yyyy') %]",
        "hoja_num":   "[% @layout_page || ' / ' || @layout_numpages %]",
    }
