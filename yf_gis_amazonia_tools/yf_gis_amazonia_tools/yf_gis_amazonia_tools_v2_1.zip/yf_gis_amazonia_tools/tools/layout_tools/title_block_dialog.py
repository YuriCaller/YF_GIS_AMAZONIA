# -*- coding: utf-8 -*-
"""
Diálogo de Title Block — generador de cajetines automáticos.
Autor: Yuri F. Caller Córdova — TUCSA / gis-amazonia.pe
"""

import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox,
    QComboBox, QLabel, QLineEdit, QDialogButtonBox,
    QPushButton, QFileDialog, QFrame, QGridLayout,
    QSizePolicy, QRadioButton, QButtonGroup, QDoubleSpinBox
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsProject

from .title_block_engine import PLANTILLAS_CAJETIN, get_variables_proyecto


class TitleBlockDialog(QDialog):
    """Diálogo para configurar y generar el cajetín."""

    def __init__(self, layout, parent=None):
        super().__init__(parent)
        self.layout = layout
        self._vars  = get_variables_proyecto()
        self.setWindowTitle("YF · Generador de Cajetín")
        self.setMinimumWidth(460)
        self._build_ui()

    def _build_ui(self):
        main = QVBoxLayout(self)
        main.setSpacing(8)

        # Cabecera
        header = QLabel(
            f"<b>Layout:</b> {self.layout.name()}<br>"
            f"Genera un cajetín de rotulación posicionado automáticamente."
        )
        header.setFrameStyle(QFrame.StyledPanel)
        header.setContentsMargins(8, 6, 8, 6)
        main.addWidget(header)

        # ── Plantilla ──
        grp_plt = QGroupBox("Plantilla de cajetín")
        plt_layout = QHBoxLayout(grp_plt)
        plt_layout.addWidget(QLabel("Plantilla:"))
        self.combo_plantilla = QComboBox()
        iconos = {
            "sencillo":           "📋",
            "bim_tecnico":        "🔵",
            "catastral_forestal": "🟢",
            "premium":            "⚫",
        }
        for key, meta in PLANTILLAS_CAJETIN.items():
            ico = iconos.get(key, "")
            self.combo_plantilla.addItem(
                f"{ico}  {meta['nombre']}  —  {meta['descripcion']}", key
            )
        self.combo_plantilla.currentIndexChanged.connect(self._on_plantilla_changed)
        plt_layout.addWidget(self.combo_plantilla)
        main.addWidget(grp_plt)

        # ── Campos del cajetín ──
        grp_campos = QGroupBox("Datos del cajetín")
        grid = QGridLayout(grp_campos)
        grid.setSpacing(5)

        def field(row, label, placeholder, default=""):
            grid.addWidget(QLabel(label), row, 0)
            txt = QLineEdit()
            txt.setPlaceholderText(placeholder)
            if default:
                txt.setText(default)
            grid.addWidget(txt, row, 1)
            return txt

        self.txt_titulo    = field(0, "Título del mapa:",
                                   "Ej: GEOREFERENCIACIÓN DE PARCELA AGRÍCOLA")
        self.txt_subtitulo = field(1, "Subtítulo / Proyecto:",
                                   "Ej: PROYECTO: FONDO CONCURSABLE SERFOR")
        self.txt_titular   = field(2, "Titular / Propietario:",
                                   "Ej: PÉREZ ALENCAR SALOMÓN")
        self.txt_elaborado = field(3, "Elaborado por:",
                                   "", self._vars.get("elaborado", ""))
        self.txt_revisado  = field(4, "Revisado por:",
                                   "Ej: Ing. ...")
        self.txt_datum     = field(5, "Datum / Proyección:",
                                   "", self._vars.get("datum", "WGS84 / UTM 19S"))
        self.txt_hoja      = field(6, "Hoja N°:", "01", "01")
        self.txt_codigo    = field(7, "Código / Expediente:",
                                   "Ej: EXP-2026-001",
                                   self._vars.get("expediente", ""))
        self.txt_empresa   = field(8, "Empresa / Institución:",
                                   "", self._vars.get("empresa", ""))
        self.txt_ubicacion = field(9, "Ubicación (pie derecho):",
                                   "Ej: Puerto Maldonado, Madre de Dios")

        main.addWidget(grp_campos)

        # Info de tamaño
        self.lbl_size = QLabel("Tamaño: 55 × 130 mm  (vertical angosto)")
        self.lbl_size.setStyleSheet(
            "color: var(--color-text-secondary, #888); font-size: 11px; "
            "padding: 2px 0;"
        )
        main.addWidget(self.lbl_size)

        # ── Logo ──
        grp_logo = QGroupBox("Logo institucional (opcional)")
        logo_layout = QHBoxLayout(grp_logo)
        self.txt_logo = QLineEdit()
        self.txt_logo.setPlaceholderText("Ruta a imagen PNG/SVG del logo...")
        btn_logo = QPushButton("📁")
        btn_logo.setMaximumWidth(30)
        btn_logo.clicked.connect(self._elegir_logo)
        logo_layout.addWidget(self.txt_logo)
        logo_layout.addWidget(btn_logo)
        main.addWidget(grp_logo)

        # ── Posición ──
        grp_pos = QGroupBox("Posición en el layout")
        pos_layout = QGridLayout(grp_pos)

        pos_layout.addWidget(QLabel("Posición:"), 0, 0)
        self.combo_pos = QComboBox()
        self.combo_pos.addItem("Esquina inferior derecha", "bottom_right")
        self.combo_pos.addItem("Esquina inferior izquierda", "bottom_left")
        self.combo_pos.addItem("Esquina superior derecha", "top_right")
        self.combo_pos.addItem("Personalizada (X, Y)", "custom")
        self.combo_pos.currentIndexChanged.connect(self._on_pos_changed)
        pos_layout.addWidget(self.combo_pos, 0, 1, 1, 2)

        pos_layout.addWidget(QLabel("X (mm):"), 1, 0)
        self.spin_x = QDoubleSpinBox()
        self.spin_x.setRange(0, 5000)
        self.spin_x.setValue(0)
        self.spin_x.setEnabled(False)
        pos_layout.addWidget(self.spin_x, 1, 1)

        pos_layout.addWidget(QLabel("Y (mm):"), 1, 2)
        self.spin_y = QDoubleSpinBox()
        self.spin_y.setRange(0, 5000)
        self.spin_y.setValue(0)
        self.spin_y.setEnabled(False)
        pos_layout.addWidget(self.spin_y, 1, 3)

        main.addWidget(grp_pos)

        # ── Botones ──
        btn_box = QDialogButtonBox()
        btn_box.addButton("✅  Generar cajetín", QDialogButtonBox.AcceptRole)
        btn_box.addButton("Cancelar",            QDialogButtonBox.RejectRole)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        main.addWidget(btn_box)

    def _on_plantilla_changed(self):
        """Actualiza info de tamaño al cambiar plantilla."""
        key = self.combo_plantilla.currentData()
        plt = PLANTILLAS_CAJETIN.get(key, {})
        w = plt.get("ancho", 100)
        h = plt.get("alto", 45)
        if hasattr(self, 'lbl_size'):
            self.lbl_size.setText(
                f"Tamaño: {w:.0f} × {h:.0f} mm  "
                f"({'vertical angosto' if h > w else 'horizontal'})"
            )

    def _elegir_logo(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar logo",
            "", "Imágenes (*.png *.jpg *.svg *.bmp)"
        )
        if path:
            self.txt_logo.setText(path)

    def _on_pos_changed(self, idx):
        custom = self.combo_pos.currentData() == "custom"
        self.spin_x.setEnabled(custom)
        self.spin_y.setEnabled(custom)

    # ─────────────────────────────────────────────────────────────────
    # Calcular posición automática
    # ─────────────────────────────────────────────────────────────────

    def _calcular_posicion(self, plantilla_key):
        from .title_block_engine import PLANTILLAS_CAJETIN, MM
        from qgis.core import QgsUnitTypes
        plt = PLANTILLAS_CAJETIN.get(plantilla_key, {})
        W_cajetin = plt.get("ancho", 100.0)
        H_cajetin = plt.get("alto",  45.0)

        page = self.layout.pageCollection().page(0)
        pw = page.pageSize().width()
        ph = page.pageSize().height()
        margen = 5.0

        pos_key = self.combo_pos.currentData()
        if pos_key == "bottom_right":
            return pw - W_cajetin - margen, ph - H_cajetin - margen
        elif pos_key == "bottom_left":
            return margen, ph - H_cajetin - margen
        elif pos_key == "top_right":
            return pw - W_cajetin - margen, margen
        else:
            return self.spin_x.value(), self.spin_y.value()

    # ─────────────────────────────────────────────────────────────────
    # Getters
    # ─────────────────────────────────────────────────────────────────

    def get_plantilla(self):
        return self.combo_plantilla.currentData()

    def get_datos(self):
        return {
            "titulo":     self.txt_titulo.text().strip(),
            "subtitulo":  self.txt_subtitulo.text().strip(),
            "titular":    self.txt_titular.text().strip(),
            "elaborado":  self.txt_elaborado.text().strip(),
            "revisado":   self.txt_revisado.text().strip(),
            "datum":      self.txt_datum.text().strip(),
            "hoja":       self.txt_hoja.text().strip(),
            "codigo":     self.txt_codigo.text().strip(),
            "empresa":    self.txt_empresa.text().strip(),
            "ubicacion":  self.txt_ubicacion.text().strip(),
        }

    def get_logo(self):
        return self.txt_logo.text().strip() or None

    def get_posicion(self):
        return self._calcular_posicion(self.get_plantilla())
