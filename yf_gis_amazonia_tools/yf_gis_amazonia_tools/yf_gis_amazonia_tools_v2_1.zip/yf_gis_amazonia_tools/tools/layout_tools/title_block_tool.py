# -*- coding: utf-8 -*-
"""
Title Block Tool — entry point para el generador de cajetines.
Autor: Yuri F. Caller Córdova — TUCSA / gis-amazonia.pe
"""

from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsPrintLayout

from ...core.base_tool import BaseTool
from ...core.logger import log_info, log_error


class Tool(BaseTool):
    """Title Block — generador de cajetines automáticos."""

    TOOL_NAME = "Generar Cajetín"

    def __init__(self, iface, plugin_dir):
        super().__init__(iface, plugin_dir)

    def run(self):
        import traceback
        try:
            layout = self._get_active_layout()
            if layout is None:
                return
            self._abrir_dialogo(layout)
        except Exception as e:
            log_error(f"Title Block: error: {e}")
            traceback.print_exc()

    def _abrir_dialogo(self, layout):
        import traceback
        try:
            from .title_block_dialog import TitleBlockDialog
            dlg = TitleBlockDialog(layout, self.iface.mainWindow())
        except Exception as e:
            log_error(f"Title Block: error construyendo diálogo: {e}")
            traceback.print_exc()
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Error — YF Cajetín",
                f"No se pudo abrir el diálogo:\n\n{e}"
            )
            return

        if dlg.exec_() != dlg.Accepted:
            return

        try:
            from .title_block_engine import generar_cajetin
            plantilla = dlg.get_plantilla()
            datos     = dlg.get_datos()
            logo      = dlg.get_logo()
            pos_x, pos_y = dlg.get_posicion()

            items = generar_cajetin(
                layout, plantilla, pos_x, pos_y,
                datos, logo_path=logo
            )

            self.iface.messageBar().pushSuccess(
                "YF · Cajetín",
                f"Cajetín generado con {len(items)} elementos en '{layout.name()}'"
            )
            log_info(
                f"Title Block: cajetín '{plantilla}' generado "
                f"en ({pos_x:.1f}, {pos_y:.1f}) mm"
            )

            # Abrir designer si no está abierto
            self.iface.openLayoutDesigner(layout)

        except Exception as e:
            log_error(f"Title Block: error generando: {e}")
            traceback.print_exc()
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Error — YF Cajetín",
                f"Error al generar el cajetín:\n\n{e}"
            )

    def _get_active_layout(self):
        from qgis.core import QgsProject
        from qgis.PyQt.QtWidgets import QInputDialog
        layouts = [
            l for l in QgsProject.instance().layoutManager().layouts()
            if isinstance(l, QgsPrintLayout)
        ]
        if not layouts:
            QMessageBox.warning(
                self.iface.mainWindow(), "YF · Cajetín",
                "No hay ningún Layout de Impresión en el proyecto."
            )
            return None
        if len(layouts) == 1:
            return layouts[0]
        nombres = [l.name() for l in layouts]
        nombre, ok = QInputDialog.getItem(
            self.iface.mainWindow(), "YF · Cajetín",
            "Selecciona el layout:", nombres, 0, False
        )
        if not ok:
            return None
        return next(l for l in layouts if l.name() == nombre)
